<div id="banner">
    <a href="/" title="Return to Home">
        <img src="img/banner.png" alt="Franklin's fine dining">    
    </a>
</div><!-- banner -->
        