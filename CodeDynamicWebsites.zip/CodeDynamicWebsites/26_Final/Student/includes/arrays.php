<?php

    $navItems = array(
    
                        array(
                            slug => "index.php",
                            title => "Home"
                        ),
                        array(
                            slug => "team.php",
                            title => "Team"
                        ),
                        array(
                            slug => "menu.php",
                            title => "Menu"
                        ),
                        array(
                            slug => "contact.php",
                            title => "Contact"
                        ),
                     );

    $teamMembers = array(
    
                            array(

                                name => "Frankie III",
                                position => "Owner",
                                bio => "Frankie is the great-grandson of the original Franlin. He is the owner of Franlin's Fine Dining. He cooks mean fritatta",
                                img =>"frankie"

                            ),
                            array(

                                name => "Frances",
                                position => "General Manager",
                                bio => "Francis knows her stuff. The big sister of Frankie himself, she runs the show. Don't miss her Margherita Mondays!",
                                img =>"francis"

                            ),
                             array(

                                name => "Carlos",
                                position => "Head Chef",
                                bio => "Carlos is the epitome of the phrase &ldquo;Don't judge a book by it's cover&rdquo; &mdash; You simply cannot find a better chef.",
                                img =>"carlos"

                            ),
    
                        );

$menuItems = array(
                    "club-sandwich" => array(
                        title => "Club Sandwich",
                        price => 11,
                        blurb => "Bacon ipsum dolor amet laborum flank magna turkey, occaecat dolor nisi in id. T-bone minim sirloin, picanha ribeye shoulder consequat boudin dolore turkey brisket et est filet mignon officia. Jerky non flank meatball salami cow picanha nulla laborum burgdoggen doner mollit ut. Lorem enim filet mignon meatball laboris tenderloin in picanha. Veniam enim fugiat porchetta tri-tip. Dolore cupidatat picanha short loin nulla aute, ham hock est cillum alcatra corned beef pig. Hamburger chicken laborum incididunt ut, doner meatball spare ribs strip steak sausage filet mignon sunt.",
                        drink => "Club Soda"
                        
                    
                    ),
                    "dill-salmon" => array(
                        title => "Lemon &amp; Dill Salmon",
                        price => 18,
                        blurb => "Mollit turkey kielbasa kevin chuck beef nulla dolor cillum meatball in quis fugiat tri-tip ea. Dolore labore shankle laborum jerky prosciutto qui beef ham hock sint commodo. Bacon capicola shankle swine consequat. Short loin consequat id consectetur, cupidatat kielbasa cillum capicola prosciutto corned beef eu dolor tri-tip. Short loin shankle lorem, short ribs pastrami landjaeger ball tip ullamco dolor ea eu spare ribs alcatra reprehenderit doner. Pig ex proident, officia aliquip t-bone elit nostrud ut esse duis nulla sausage labore. Laborum swine kevin non fatback, alcatra exercitation do aliqua.",
                        drink => "Fancy Wine"
                    
                    ),
                    "super-salad" => array(
                        title => "The Super Salad<sup>&reg;</sup>",
                        price => 11,
                        blurb => "Gumbo beet greens corn soko endive gumbo gourd. Parsley shallot courgette tatsoi pea sprouts fava bean collard greens dandelion okra wakame tomato. Dandelion cucumber earthnut pea peanut soko zucchini.",
                        drink => "Jug o' water"
                    
                    ),
                    "mexican-barbacoa" => array(
                        title => "Mexican Barbacoa",
                        price => 23,
                        blurb => "Lemon drops jelly beans chocolate cake chupa chups soufflé pie brownie tiramisu chocolate bar. Chocolate cake sesame snaps sweet roll lollipop pastry. Cookie candy canes sweet roll dessert apple pie tart. Jelly danish jelly sugar plum powder. Brownie wafer icing chocolate wafer pastry jelly. Icing apple pie lollipop gummies. Muffin cake brownie gingerbread donut chupa chups halvah.",
                        drink => "Beer with lime"
                    
                    )









);
    
?>
