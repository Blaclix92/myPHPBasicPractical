<?php include 'arrays.php'; ?>
<head>
    <title><?php echo TITLE; ?></title>
    <link href="/assets/styles.css" rel="stylesheet">
</head>