<!DOCTYPE html>
<html>
<?php 
    define("TITLE","Menu | Frakinlin's Fine Dining");
    include 'includes/header.php';
    ?>
<body id="final-example">
    <div class="wrapper">
        <!-- include header-->
        <?php include 'includes/banner.php'; ?>
        <!-- include nav -->
        <?php include 'includes/nav.php'; ?>
        <div class="content">
            <div id="menu-items">
            
                <h1>Oor Delicious Menu</h1>
                <p>Like our team, our menu is very smal &mdash; but dang, does it ever pack a punck</p>
                <p><em>Click any menu to learn more about it.</em></p>
		        <hr>
                
                <ul>
                    <?php 
                    
                        foreach($menuItems as $dish => $item){ ?>
                            
                            <li><a href="dish.php?item=<?php echo $dish; ?> ">
                                <?php echo $item[title]; ?></a> <sup>$</sup><?php echo $item[price]; ?></li>
                            
                     <?php   } ?>
                </ul>
     
            </div>
        <hr>
            
            <!-- inlcude footer-->
            <?php include 'includes/footer.php'; ?>
        </div>
    </div><!-- wrapper -->
    <div class="copyright-info">
        <?php include('/assets/includes/copyright.php'); ?>
    </div><!-- copyright info -->
</body>
</html>